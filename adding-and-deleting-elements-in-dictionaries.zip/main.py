# Creating a Dictionary 
print("This is a normal dictionary")
books = {
    "Day": "Sunday",
    "Date": "16"
}

print(books)
print("This is adding an element")

# adding an element in Dictionary

books["Month"] = "March"

print(books)

# deleting an element
print("this is removing an element")

books.pop("Month")

print(books)

